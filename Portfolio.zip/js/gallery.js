//Darkmode
function dark () {
    var element = document.body;//Sets the variable element equal to the HTML body
    element.classList.toggle('darkmode');//This allows darkmode to be toggled on and off
}